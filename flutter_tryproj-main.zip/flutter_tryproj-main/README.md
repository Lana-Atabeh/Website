# flutter_try

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


## Wedding Planner 
<img src="https://user-images.githubusercontent.com/93736802/228666365-8c379f9d-bab6-4c57-879c-574d49c1c298.jpg" width="400" height="800" />

## 3 Level of users 
<img src="https://user-images.githubusercontent.com/93736802/228674116-0864e3d1-3def-4998-bbcd-5848ed42d888.jpg" width="400" height="800" />

## main page
<img src="https://user-images.githubusercontent.com/93736802/228675348-60b67836-c277-4611-8b64-5236e6b0e8a7.jpg" width="400" height="800" />

## Detail page
<img src="https://user-images.githubusercontent.com/93736802/228675955-2cc78a8c-b8d3-4490-97ad-015d59ef322c.jpg" width="400" height="800" />

## Map page
<img src="https://user-images.githubusercontent.com/93736802/228676005-747d2c3d-a214-4231-ac1a-1a525874b941.jpg" width="400" height="800" />

