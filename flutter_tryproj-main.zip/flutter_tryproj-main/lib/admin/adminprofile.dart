import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
class adminProfileTab extends StatefulWidget{
  const adminProfileTab({Key? key}):super(key:key);
  @override
  _adminProfileTabState createState()=> _adminProfileTabState();


}
class _adminProfileTabState extends State<adminProfileTab>{


  @override
  Widget build(BuildContext context) {
    return Container();
}}