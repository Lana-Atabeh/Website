
import 'package:flutter/cupertino.dart';

class Wedding_cars extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      child: Center(child: Text("welcome to wedding cars")),
    );
    throw UnimplementedError();
  }

}